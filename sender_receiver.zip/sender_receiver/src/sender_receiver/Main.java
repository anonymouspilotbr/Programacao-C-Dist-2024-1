package sender_receiver;

public class Main {
	public static void main(String[] args) {
		Data data = new Data();
		String [] messages = {
				"message 1",
				"message 2",
				"message 3",
				"message 4",
				"END",
		};
		
		Sender s1 = new Sender(data, messages);
		Receiver r1 = new Receiver(data);
		
		s1.start();
		r1.start();
	}
}
