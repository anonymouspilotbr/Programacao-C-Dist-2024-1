package sender_receiver;

public class Data {
	private String message;
	private boolean isSending = true;
	
	public synchronized void send(String message) {
		while(!isSending) {
			System.out.println("Esperando fim do recebimento...");
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("Thread interrompida");
			}
		}
		this.message = message;
		System.out.println("Mensagem enviada: " + this.message);
		
		isSending = false;
		notify();
	}
	
	public synchronized String receive() {
		while(isSending) {
			System.out.println("Esperando fim do envio...");
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("Thread interrompida");
			}
		}
		String receivedMessage = this.message;
		System.out.println("Mensagem recebida: " + receivedMessage);
		
		isSending = true;
		
		notify();
		return receivedMessage;
	}
}
